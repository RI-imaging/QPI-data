sample: HL60/S4 cells
medium: phosphate buffered saline (PBS, n=1.335)
imaging wavelength: 633nm
pixel size: 0.107µm
imaging technique: digital holography
date of acquisition: 2015/10/29

context:
These data were part of a comparison between several refractive index retrieval
techniques for spherical objects as part of the publication (figure 5d):

  Paul Müller, Mirjam Schürmann, Salvatore Girardo, Gheorghe Cojoc,
  and Jochen Guck 
  "Accurate evaluation of size and refractive index for spherical
  objects in quantitative phase imaging,"
  Optics Express 26(8): 10729-10743, 2018.
  doi:10.1364/OE.26.010729

license: CC0
These data are dedicated to the public domain. You can copy, modify,
or distribute them without asking permission.

