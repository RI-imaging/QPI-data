sample: polyacrylamide (PAA) microgel bead
medium: phosphate buffered saline (PBS, n=1.335)
imaging wavelength: 647nm
pixel size: 0.14µm
imaging techniuqe: shearing interferometry (SID4Bio, Phasics S.A.)
date of acquisition: 2017/01/06

context:
These data were used to verify the tomographic refractive index
reconstruction of a microgel-glass-cell-phantom as part of the
publication (supplementary figure 2a):

  M. Schürmann, G. Cojoc, S. Girardo, E. Ulbricht, J. Guck,
  and P. Müller,
  "Three-dimensional correlative single-cell imaging utilizing
  fluorescence and refractive index tomography,"
  Journal of Biophotonics 11(3): e201700145, 2017.
  doi:10.1002/jbio.201700145

The average refractive index of the microgel beads (1.356 +/- 0.004)
was determined using the edge detection approach as described in:

  M. Schürmann, J. Scholze, P. Müller, J. Guck, and C. J. Chan,
  "Cell nuclei have lower refractive index and mass density than
  cytoplasm,"
  Journal of Biophotonics 9(10): 1068–1076, 2016.
  doi:10.1002/jbio.201500273

license: CC0
These data are dedicated to the public domain. You can copy, modify,
or distribute them without asking permission.

