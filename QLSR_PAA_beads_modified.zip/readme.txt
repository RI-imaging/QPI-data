sample: polyacrylamide (PAA) microgel bead with artificial background artifacts
medium: phosphate buffered saline (PBS, n=1.335)
imaging wavelength: 647nm
pixel size: 0.14µm
imaging technique: shearing interferometry (SID4Bio, Phasics S.A.)
date of acquisition: 2017/01/06

context:
The original data are located in the file QLSR_PAA_beads.zip which should
be available at the same location as this archive. The manually added
background artifacts were used to demonstrate the capabilities of the
quantitative phase imaging analysis software DryMass.

license: CC0
These data are dedicated to the public domain. You can copy, modify,
or distribute them without asking permission.

